/**
 * ASICOM — main.js
 * Navigation, FAQ accordéon, compteurs animés, scroll effects
 */

document.addEventListener('DOMContentLoaded', function () {

  /* ============================================================
     NAVIGATION MOBILE — Hamburger toggle
     ============================================================ */
  const navToggle   = document.getElementById('nav-toggle');
  const mobileMenu  = document.getElementById('mobile-menu');
  const siteHeader  = document.getElementById('site-header');

  if (navToggle && mobileMenu) {
    navToggle.addEventListener('click', function () {
      const isOpen = mobileMenu.classList.toggle('is-open');
      navToggle.setAttribute('aria-expanded', String(isOpen));
      mobileMenu.setAttribute('aria-hidden', String(!isOpen));
      navToggle.classList.toggle('is-active', isOpen);
    });

    // Fermer en cliquant en dehors
    document.addEventListener('click', function (e) {
      if (!siteHeader.contains(e.target)) {
        mobileMenu.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
        mobileMenu.setAttribute('aria-hidden', 'true');
        navToggle.classList.remove('is-active');
      }
    });

    // Fermer sur touche Escape
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && mobileMenu.classList.contains('is-open')) {
        mobileMenu.classList.remove('is-open');
        navToggle.setAttribute('aria-expanded', 'false');
        mobileMenu.setAttribute('aria-hidden', 'true');
        navToggle.classList.remove('is-active');
        navToggle.focus();
      }
    });
  }

  /* ============================================================
     HEADER STICKY — Ombre au scroll
     ============================================================ */
  if (siteHeader) {
    const onScroll = function () {
      siteHeader.classList.toggle('scrolled', window.scrollY > 50);
    };
    window.addEventListener('scroll', onScroll, { passive: true });
    onScroll();
  }

  /* ============================================================
     FAQ ACCORDÉON
     ============================================================ */
  const faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(function (item) {
    const question = item.querySelector('.faq-item__question');
    const answer   = item.querySelector('.faq-item__answer');
    const icon     = item.querySelector('.faq-item__icon');

    if (!question || !answer) return;

    question.addEventListener('click', function () {
      const isOpen = item.classList.contains('is-open');

      // Fermer tous les autres
      faqItems.forEach(function (other) {
        if (other !== item) {
          other.classList.remove('is-open');
          const otherQ = other.querySelector('.faq-item__question');
          if (otherQ) otherQ.setAttribute('aria-expanded', 'false');
        }
      });

      // Toggle courant
      item.classList.toggle('is-open', !isOpen);
      question.setAttribute('aria-expanded', String(!isOpen));
    });

    // Accessibilité
    question.setAttribute('aria-expanded', 'false');
    question.setAttribute('role', 'button');
    const answerId = 'faq-answer-' + Math.random().toString(36).substr(2, 9);
    answer.id = answerId;
    question.setAttribute('aria-controls', answerId);
  });

  /* ============================================================
     COMPTEURS ANIMÉS — Stats
     ============================================================ */
  const counters = document.querySelectorAll('[data-counter]');

  if (counters.length > 0) {
    const animateCounter = function (el) {
      const target   = parseFloat(el.getAttribute('data-counter'));
      const suffix   = el.getAttribute('data-suffix') || '';
      const duration = 2000;
      const start    = performance.now();
      const isFloat  = target !== Math.floor(target);

      const step = function (now) {
        const elapsed  = now - start;
        const progress = Math.min(elapsed / duration, 1);
        // Ease out cubic
        const eased    = 1 - Math.pow(1 - progress, 3);
        const value    = eased * target;
        el.textContent = (isFloat ? value.toFixed(1) : Math.floor(value)) + suffix;

        if (progress < 1) {
          requestAnimationFrame(step);
        } else {
          el.textContent = target + suffix;
        }
      };
      requestAnimationFrame(step);
    };

    // Démarrer quand visible (Intersection Observer)
    if ('IntersectionObserver' in window) {
      const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            animateCounter(entry.target);
            observer.unobserve(entry.target);
          }
        });
      }, { threshold: 0.3 });

      counters.forEach(function (counter) {
        observer.observe(counter);
      });
    } else {
      // Fallback sans Observer
      counters.forEach(animateCounter);
    }
  }

  /* ============================================================
     SMOOTH SCROLL — Liens ancres
     ============================================================ */
  document.querySelectorAll('a[href^="#"]').forEach(function (link) {
    link.addEventListener('click', function (e) {
      const targetId = this.getAttribute('href');
      if (targetId === '#') return;
      const target = document.querySelector(targetId);
      if (target) {
        e.preventDefault();
        const headerHeight = siteHeader ? siteHeader.offsetHeight : 80;
        const top = target.getBoundingClientRect().top + window.scrollY - headerHeight - 20;
        window.scrollTo({ top, behavior: 'smooth' });
      }
    });
  });

  /* ============================================================
     ANIMATIONS AU SCROLL — Apparition des éléments
     ============================================================ */
  if ('IntersectionObserver' in window) {
    const animElements = document.querySelectorAll('.animate-in');

    const animObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-visible');
          animObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.1, rootMargin: '0px 0px -50px 0px' });

    animElements.forEach(function (el) {
      animObserver.observe(el);
    });
  }

  /* ============================================================
     GALERIE PROJET — Image secondaire au hover
     ============================================================ */
  const projectCards = document.querySelectorAll('.portfolio-card');
  projectCards.forEach(function (card) {
    const img = card.querySelector('.portfolio-card__logo img');
    const alt = img ? img.getAttribute('data-hover-src') : null;
    if (!img || !alt) return;

    const originalSrc = img.src;
    card.addEventListener('mouseenter', function () { img.src = alt; });
    card.addEventListener('mouseleave', function () { img.src = originalSrc; });
  });

});

/* ============================================================
   CSS ANIMATIONS — Injection des styles
   ============================================================ */
(function () {
  const style = document.createElement('style');
  style.textContent = `
    .animate-in {
      opacity: 0;
      transform: translateY(24px);
      transition: opacity 0.6s ease, transform 0.6s ease;
    }
    .animate-in.is-visible {
      opacity: 1;
      transform: translateY(0);
    }
    .animate-in:nth-child(2) { transition-delay: 0.1s; }
    .animate-in:nth-child(3) { transition-delay: 0.2s; }
    .animate-in:nth-child(4) { transition-delay: 0.3s; }
    .nav-toggle.is-active span:nth-child(1) {
      transform: translateY(7px) rotate(45deg);
    }
    .nav-toggle.is-active span:nth-child(2) {
      opacity: 0;
    }
    .nav-toggle.is-active span:nth-child(3) {
      transform: translateY(-7px) rotate(-45deg);
    }
  `;
  document.head.appendChild(style);
})();
