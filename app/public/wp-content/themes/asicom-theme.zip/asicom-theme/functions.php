<?php
/**
 * ASICOM Theme — functions.php
 * Société Algéro-Saoudienne d'Investissement
 */

if ( ! defined( 'ABSPATH' ) ) exit;

define( 'ASICOM_VERSION', '1.0.0' );
define( 'ASICOM_DIR', get_template_directory() );
define( 'ASICOM_URI', get_template_directory_uri() );

/* ============================================================
   THEME SUPPORT
   ============================================================ */
function asicom_setup() {
    load_theme_textdomain( 'asicom', ASICOM_DIR . '/languages' );

    add_theme_support( 'title-tag' );
    add_theme_support( 'post-thumbnails' );
    add_theme_support( 'html5', [ 'search-form', 'comment-form', 'comment-list', 'gallery', 'caption', 'style', 'script' ] );
    add_theme_support( 'custom-logo', [
        'height'      => 80,
        'width'       => 200,
        'flex-height' => true,
        'flex-width'  => true,
    ]);
    add_theme_support( 'responsive-embeds' );
    add_theme_support( 'editor-styles' );

    // Tailles d'images personnalisées
    add_image_size( 'hero-bg',        1920, 600, true );
    add_image_size( 'project-thumb',   800, 500, true );
    add_image_size( 'project-logo',    300, 200, false );
    add_image_size( 'team-portrait',   400, 500, true );
}
add_action( 'after_setup_theme', 'asicom_setup' );

/* ============================================================
   ENQUEUE SCRIPTS & STYLES
   ============================================================ */
function asicom_enqueue_assets() {
    // Google Fonts
    wp_enqueue_style(
        'asicom-fonts',
        'https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;800&family=Inter:wght@400;500;600&display=swap',
        [],
        null
    );

    // Style principal
    wp_enqueue_style(
        'asicom-style',
        ASICOM_URI . '/style.css',
        [ 'asicom-fonts' ],
        ASICOM_VERSION
    );

    // Script principal
    wp_enqueue_script(
        'asicom-main',
        ASICOM_URI . '/assets/js/main.js',
        [],
        ASICOM_VERSION,
        true
    );

    // Localisation JS (données PHP → JS)
    wp_localize_script( 'asicom-main', 'ASICOM', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce'   => wp_create_nonce( 'asicom_nonce' ),
        'homeUrl' => home_url('/'),
        'lang'    => get_locale(),
    ]);
}
add_action( 'wp_enqueue_scripts', 'asicom_enqueue_assets' );

/* ============================================================
   ENREGISTREMENT DES MENUS
   ============================================================ */
function asicom_register_menus() {
    register_nav_menus([
        'primary'   => __( 'Menu principal', 'asicom' ),
        'footer'    => __( 'Menu footer', 'asicom' ),
    ]);
}
add_action( 'init', 'asicom_register_menus' );

/* ============================================================
   CUSTOM POST TYPE — PROJETS (PORTEFEUILLE)
   ============================================================ */
function asicom_register_cpt_projet() {
    $labels = [
        'name'               => __( 'Projets', 'asicom' ),
        'singular_name'      => __( 'Projet', 'asicom' ),
        'add_new'            => __( 'Ajouter un projet', 'asicom' ),
        'add_new_item'       => __( 'Ajouter un nouveau projet', 'asicom' ),
        'edit_item'          => __( 'Modifier le projet', 'asicom' ),
        'new_item'           => __( 'Nouveau projet', 'asicom' ),
        'view_item'          => __( 'Voir le projet', 'asicom' ),
        'search_items'       => __( 'Rechercher un projet', 'asicom' ),
        'not_found'          => __( 'Aucun projet trouvé', 'asicom' ),
        'not_found_in_trash' => __( 'Aucun projet dans la corbeille', 'asicom' ),
        'menu_name'          => __( 'Portefeuille', 'asicom' ),
    ];

    $args = [
        'labels'             => $labels,
        'public'             => true,
        'publicly_queryable' => true,
        'show_ui'            => true,
        'show_in_menu'       => true,
        'query_var'          => true,
        'rewrite'            => [ 'slug' => 'projets' ],
        'capability_type'    => 'post',
        'has_archive'        => true,
        'hierarchical'       => false,
        'menu_position'      => 5,
        'menu_icon'          => 'dashicons-building',
        'supports'           => [ 'title', 'editor', 'thumbnail', 'excerpt' ],
        'show_in_rest'       => true,
    ];

    register_post_type( 'projet', $args );
}
add_action( 'init', 'asicom_register_cpt_projet' );

/* ============================================================
   TAXONOMIE — STATUT PROJET (En exploitation / Exit)
   ============================================================ */
function asicom_register_taxonomy_statut() {
    $labels = [
        'name'          => __( 'Statuts', 'asicom' ),
        'singular_name' => __( 'Statut', 'asicom' ),
        'search_items'  => __( 'Rechercher un statut', 'asicom' ),
        'all_items'     => __( 'Tous les statuts', 'asicom' ),
        'edit_item'     => __( 'Modifier le statut', 'asicom' ),
        'add_new_item'  => __( 'Ajouter un statut', 'asicom' ),
    ];

    register_taxonomy( 'statut_projet', 'projet', [
        'hierarchical'      => true,
        'labels'            => $labels,
        'show_ui'           => true,
        'show_admin_column' => true,
        'query_var'         => true,
        'rewrite'           => [ 'slug' => 'statut' ],
        'show_in_rest'      => true,
    ]);
}
add_action( 'init', 'asicom_register_taxonomy_statut' );

/* ============================================================
   ACF — CHAMPS PERSONNALISÉS POUR LES PROJETS
   ============================================================ */
function asicom_register_acf_fields() {
    if ( ! function_exists('acf_add_local_field_group') ) return;

    acf_add_local_field_group([
        'key'      => 'group_projet_details',
        'title'    => 'Détails du projet',
        'fields'   => [

            // Informations générales
            [
                'key'           => 'field_denomination',
                'label'         => 'Dénomination de la société',
                'name'          => 'denomination',
                'type'          => 'text',
                'instructions'  => 'Nom complet de la société (ex: OCEANO CENTER)',
                'required'      => 1,
                'placeholder'   => 'Ex: OCEANO CENTER',
            ],
            [
                'key'           => 'field_forme_juridique',
                'label'         => 'Forme juridique',
                'name'          => 'forme_juridique',
                'type'          => 'select',
                'choices'       => [
                    'spa'       => 'Société par Actions (SPA)',
                    'sarl'      => 'SARL',
                    'eurl'      => 'EURL',
                    'snc'       => 'SNC',
                    'autre'     => 'Autre',
                ],
                'default_value' => 'spa',
                'allow_null'    => 0,
                'ui'            => 1,
            ],
            [
                'key'           => 'field_capital_social',
                'label'         => 'Capital social',
                'name'          => 'capital_social',
                'type'          => 'text',
                'placeholder'   => 'Ex: 3 851 190 000 DA',
            ],
            [
                'key'           => 'field_taux_participation',
                'label'         => 'Taux de participation (%)',
                'name'          => 'taux_participation',
                'type'          => 'number',
                'min'           => 0,
                'max'           => 100,
                'step'          => 0.01,
                'append'        => '%',
                'placeholder'   => 'Ex: 67',
            ],
            [
                'key'           => 'field_siege_social',
                'label'         => 'Siège social',
                'name'          => 'siege_social',
                'type'          => 'textarea',
                'rows'          => 2,
                'placeholder'   => 'Adresse complète du siège social',
            ],
            [
                'key'           => 'field_activite',
                'label'         => 'Activité',
                'name'          => 'activite',
                'type'          => 'text',
                'placeholder'   => 'Ex: Centre commercial City Center',
            ],
            [
                'key'           => 'field_postes',
                'label'         => 'Postes directs et indirects',
                'name'          => 'postes',
                'type'          => 'text',
                'placeholder'   => 'Ex: 250 postes',
            ],
            [
                'key'           => 'field_wilaya',
                'label'         => 'Wilaya',
                'name'          => 'wilaya',
                'type'          => 'select',
                'choices'       => [
                    'alger'       => 'Wilaya d\'Alger',
                    'blida'       => 'Wilaya de Blida',
                    'bejaia'      => 'Wilaya de Béjaïa',
                    'constantine' => 'Wilaya de Constantine',
                    'khenchela'   => 'Wilaya de Khenchela',
                    'skikda'      => 'Wilaya de Skikda',
                    'autre'       => 'Autre',
                ],
                'allow_null'    => 1,
                'ui'            => 1,
            ],
            [
                'key'           => 'field_site_web',
                'label'         => 'Site web',
                'name'          => 'site_web',
                'type'          => 'url',
                'placeholder'   => 'https://...',
            ],
            [
                'key'           => 'field_logo',
                'label'         => 'Logo du projet',
                'name'          => 'logo',
                'type'          => 'image',
                'return_format' => 'array',
                'preview_size'  => 'medium',
                'library'       => 'all',
            ],
            [
                'key'           => 'field_image_secondaire',
                'label'         => 'Image secondaire',
                'name'          => 'image_secondaire',
                'type'          => 'image',
                'return_format' => 'array',
                'preview_size'  => 'medium',
                'library'       => 'all',
            ],
            [
                'key'           => 'field_annee_debut',
                'label'         => 'Année de démarrage',
                'name'          => 'annee_debut',
                'type'          => 'number',
                'min'           => 2000,
                'max'           => 2030,
                'placeholder'   => 'Ex: 2015',
            ],
            [
                'key'           => 'field_ordre_affichage',
                'label'         => 'Ordre d\'affichage',
                'name'          => 'ordre_affichage',
                'type'          => 'number',
                'default_value' => 10,
                'instructions'  => 'Nombre plus bas = affiché en premier',
            ],
        ],
        'location'  => [
            [[ 'param' => 'post_type', 'operator' => '==', 'value' => 'projet' ]]
        ],
        'menu_order'            => 0,
        'position'              => 'normal',
        'style'                 => 'default',
        'label_placement'       => 'top',
        'instruction_placement' => 'label',
    ]);

    // Champs pour les options du thème
    if ( function_exists('acf_add_options_page') ) {
        acf_add_options_page([
            'page_title' => 'Options ASICOM',
            'menu_title' => 'Options ASICOM',
            'menu_slug'  => 'asicom-options',
            'capability' => 'edit_posts',
            'redirect'   => false,
            'icon_url'   => 'dashicons-admin-site',
        ]);

        acf_add_local_field_group([
            'key'    => 'group_options_asicom',
            'title'  => 'Paramètres généraux',
            'fields' => [
                [
                    'key'   => 'field_opt_phone_1',
                    'label' => 'Téléphone 1',
                    'name'  => 'phone_1',
                    'type'  => 'text',
                    'placeholder' => '+213 20 116 700',
                ],
                [
                    'key'   => 'field_opt_phone_2',
                    'label' => 'Téléphone 2 (Fax)',
                    'name'  => 'phone_2',
                    'type'  => 'text',
                    'placeholder' => '+213 20 118 915',
                ],
                [
                    'key'   => 'field_opt_email',
                    'label' => 'Email',
                    'name'  => 'email',
                    'type'  => 'email',
                    'placeholder' => 'contact@asicom.dz',
                ],
                [
                    'key'   => 'field_opt_adresse',
                    'label' => 'Adresse',
                    'name'  => 'adresse',
                    'type'  => 'text',
                    'placeholder' => 'Val d\'Hydra Ben Aknoun, Alger',
                ],
                [
                    'key'   => 'field_opt_linkedin',
                    'label' => 'LinkedIn URL',
                    'name'  => 'linkedin',
                    'type'  => 'url',
                ],
                [
                    'key'           => 'field_opt_maps_embed',
                    'label'         => 'Code embed Google Maps (iframe)',
                    'name'          => 'maps_embed',
                    'type'          => 'textarea',
                    'rows'          => 3,
                    'instructions'  => 'Coller le code iframe fourni par Google Maps',
                ],
                [
                    'key'   => 'field_opt_stats_annees',
                    'label' => 'Stat : Années d\'expérience',
                    'name'  => 'stat_annees',
                    'type'  => 'number',
                    'default_value' => 17,
                ],
                [
                    'key'   => 'field_opt_stats_valeur',
                    'label' => 'Stat : Valeur des participations (ex: 7 756 MDA)',
                    'name'  => 'stat_valeur',
                    'type'  => 'text',
                    'default_value' => '7 756 MDA',
                ],
                [
                    'key'   => 'field_opt_stats_participations',
                    'label' => 'Stat : Participations en portefeuille',
                    'name'  => 'stat_participations',
                    'type'  => 'number',
                    'default_value' => 8,
                ],
                [
                    'key'   => 'field_opt_stats_exit',
                    'label' => 'Stat : Exit',
                    'name'  => 'stat_exit',
                    'type'  => 'number',
                    'default_value' => 6,
                ],
            ],
            'location' => [
                [[ 'param' => 'options_page', 'operator' => '==', 'value' => 'asicom-options' ]]
            ],
        ]);
    }
}
add_action( 'acf/init', 'asicom_register_acf_fields' );

/* ============================================================
   HELPER — récupérer les options ACF du thème
   ============================================================ */
function asicom_option( $key, $default = '' ) {
    if ( function_exists('get_field') ) {
        $val = get_field( $key, 'option' );
        return $val ?: $default;
    }
    return $default;
}

/* ============================================================
   HELPERS — projets
   ============================================================ */
function asicom_get_projects( $args = [] ) {
    $defaults = [
        'post_type'      => 'projet',
        'posts_per_page' => -1,
        'post_status'    => 'publish',
        'orderby'        => 'meta_value_num',
        'meta_key'       => 'ordre_affichage',
        'order'          => 'ASC',
    ];
    return get_posts( wp_parse_args( $args, $defaults ) );
}

/* ============================================================
   PAGINATION PERSONNALISÉE
   ============================================================ */
function asicom_pagination() {
    global $wp_query;
    $big = 999999999;

    $links = paginate_links([
        'base'    => str_replace( $big, '%#%', esc_url( get_pagenum_link($big) ) ),
        'format'  => '?paged=%#%',
        'current' => max(1, get_query_var('paged')),
        'total'   => $wp_query->max_num_pages,
        'type'    => 'array',
        'prev_text' => '← Précédent',
        'next_text' => 'Suivant →',
    ]);

    if ( ! $links ) return;

    echo '<nav class="pagination" aria-label="Pagination">';
    echo '<ul class="pagination__list">';
    foreach ( $links as $link ) {
        $active = strpos($link, 'current') !== false ? ' class="pagination__item--active"' : '';
        echo "<li{$active}>{$link}</li>";
    }
    echo '</ul></nav>';
}

/* ============================================================
   EXCERPT PERSONNALISÉ
   ============================================================ */
function asicom_excerpt_length( $length ) { return 25; }
add_filter( 'excerpt_length', 'asicom_excerpt_length' );

function asicom_excerpt_more( $more ) { return '…'; }
add_filter( 'excerpt_more', 'asicom_excerpt_more' );

/* ============================================================
   SÉCURITÉ — désactiver les informations inutiles
   ============================================================ */
remove_action( 'wp_head', 'wp_generator' );
remove_action( 'wp_head', 'wlwmanifest_link' );
remove_action( 'wp_head', 'rsd_link' );
add_filter( 'the_generator', '__return_empty_string' );

/* ============================================================
   DÉSACTIVER GUTENBERG pour les types simples (optionnel)
   ============================================================ */
// Décommenter si vous n'utilisez pas Gutenberg :
// add_filter( 'use_block_editor_for_post', '__return_false' );

/* ============================================================
   FLUSH REWRITE RULES après activation du thème
   ============================================================ */
function asicom_flush_rewrite_rules() {
    asicom_register_cpt_projet();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'asicom_flush_rewrite_rules' );
add_action( 'after_switch_theme', 'asicom_flush_rewrite_rules' );
