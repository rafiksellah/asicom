<?php
$phone_1  = asicom_option('phone_1', '+213 20 116 700 /760');
$phone_2  = asicom_option('phone_2', '+213 20 118 915');
$email    = asicom_option('email', 'contact@asicom.dz');
$adresse  = asicom_option('adresse', "Val d'Hydra Ben Aknoun, Alger");
$linkedin = asicom_option('linkedin', '#');
$maps     = asicom_option('maps_embed', '');
?>

<!-- ============================================================
     CTA BANNER — Réutilisable (inclus automatiquement)
     ============================================================ -->
<?php if ( ! is_page('rendez-vous') ) : ?>
<section class="cta-banner" aria-labelledby="cta-title">
    <div class="container">
        <div class="cta-banner__content">
            <h2 class="cta-banner__title" id="cta-title">
                Prêt à booster votre projet
            </h2>
            <p class="cta-banner__text">
                Nous nous réjouissons d'avoir de vos nouvelles et de vous aider dans votre parcours.
            </p>
            <a href="<?php echo esc_url( home_url('/rendez-vous/') ); ?>" class="btn btn--outline-white">
                Nous contacter
            </a>
        </div>
    </div>
</section>
<?php endif; ?>

<!-- ============================================================
     FOOTER
     ============================================================ -->
<footer class="site-footer" role="contentinfo">
    <div class="container">
        <div class="footer__grid">

            <!-- Colonne 1 : Logo + tagline -->
            <div class="footer__col">
                <a href="<?php echo esc_url( home_url('/') ); ?>" class="footer__logo">
                    <?php if ( has_custom_logo() ) : the_custom_logo();
                    else : ?>
                        <img
                            src="<?php echo esc_url( ASICOM_URI . '/assets/images/logo-asicom.png' ); ?>"
                            alt="ASICOM"
                            width="120"
                            height="56"
                            loading="lazy"
                        >
                    <?php endif; ?>
                </a>
                <p class="footer__tagline">
                    الشركة الجزائرية السعودية للإستثمار<br>
                    Société Algéro-Saoudienne d'Investissement
                </p>
            </div>

            <!-- Colonne 2 : Compagnie -->
            <div class="footer__col">
                <h3 class="footer__heading">Compagnie</h3>
                <nav class="footer__links" aria-label="Liens footer">
                    <a href="<?php echo esc_url( home_url('/a-propos/') ); ?>">A propos</a>
                    <a href="<?php echo esc_url( home_url('/projets/') ); ?>">Portefeuille</a>
                    <a href="<?php echo esc_url( home_url('/rendez-vous/') ); ?>">Rendez-vous</a>
                </nav>
            </div>

            <!-- Colonne 3 : Contact -->
            <div class="footer__col">
                <h3 class="footer__heading">Nous contacter</h3>

                <div class="footer__contact-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 10.8 19.79 19.79 0 01.22 2.18 2 2 0 012.18 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 7.09a16 16 0 006 6l.63-.63a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z"/>
                    </svg>
                    <a href="tel:<?php echo esc_attr( preg_replace('/\s/', '', $phone_1) ); ?>"><?php echo esc_html($phone_1); ?></a>
                </div>

                <div class="footer__contact-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <rect x="2" y="3" width="20" height="14" rx="2" ry="2"/>
                        <path d="M8 21h8M12 17v4"/>
                    </svg>
                    <span><?php echo esc_html($phone_2); ?></span>
                </div>

                <div class="footer__contact-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                        <polyline points="22,6 12,13 2,6"/>
                    </svg>
                    <a href="mailto:<?php echo esc_attr($email); ?>"><?php echo esc_html($email); ?></a>
                </div>

                <div class="footer__contact-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/>
                        <circle cx="12" cy="10" r="3"/>
                    </svg>
                    <span><?php echo esc_html($adresse); ?></span>
                </div>

                <!-- Réseaux sociaux -->
                <div class="footer__social">
                    <a href="<?php echo esc_url($linkedin); ?>" target="_blank" rel="noopener noreferrer" aria-label="LinkedIn ASICOM">
                        <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor" aria-hidden="true">
                            <path d="M16 8a6 6 0 016 6v7h-4v-7a2 2 0 00-2-2 2 2 0 00-2 2v7h-4v-7a6 6 0 016-6zM2 9h4v12H2z"/>
                            <circle cx="4" cy="4" r="2"/>
                        </svg>
                    </a>
                </div>
            </div>

            <!-- Colonne 4 : Carte -->
            <?php if ( $maps ) : ?>
            <div class="footer__col">
                <div class="footer__map">
                    <?php echo wp_kses( $maps, [ 'iframe' => [
                        'src' => true, 'width' => true, 'height' => true,
                        'style' => true, 'allowfullscreen' => true,
                        'loading' => true, 'referrerpolicy' => true,
                        'frameborder' => true,
                    ]]); ?>
                </div>
            </div>
            <?php endif; ?>

        </div>
    </div>

    <!-- Footer bottom bar -->
    <div class="footer__bottom">
        <div class="container" style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:1rem;">
            <span>&copy; <?php echo esc_html( date('Y') ); ?> Consulting Firm. All rights reserved.</span>
            <nav class="footer__bottom-links" aria-label="Liens légaux">
                <a href="<?php echo esc_url( home_url('/privacy-policy/') ); ?>">Privacy Policy</a>
                <a href="<?php echo esc_url( home_url('/terms-conditions/') ); ?>">Terms &amp; Conditions</a>
                <a href="<?php echo esc_url( home_url('/cookie-policy/') ); ?>">Cookie Policy</a>
            </nav>
        </div>
    </div>

</footer>

<?php wp_footer(); ?>
</body>
</html>
