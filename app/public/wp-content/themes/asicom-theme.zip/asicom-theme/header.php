<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<!-- ============================================================
     TOP BAR
     ============================================================ -->
<div class="topbar" role="banner">
    <div class="container">
        <div class="topbar__inner">

            <div class="topbar__contacts">
                <?php
                $phone_1 = asicom_option('phone_1', '+213 20 116 700 /760');
                $phone_2 = asicom_option('phone_2', '+213 20 118 915');
                $email   = asicom_option('email', 'contact@asicom.dz');
                ?>

                <a href="tel:<?php echo esc_attr( preg_replace('/\s/', '', $phone_1) ); ?>" class="topbar__contact-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 10.8 19.79 19.79 0 01.22 2.18 2 2 0 012.18 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.91 7.09a16 16 0 006 6l.63-.63a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 14.92z"/>
                    </svg>
                    <?php echo esc_html( $phone_1 ); ?>
                </a>

                <a href="mailto:<?php echo esc_attr( $email ); ?>" class="topbar__contact-item">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                        <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                        <polyline points="22,6 12,13 2,6"/>
                    </svg>
                    <?php echo esc_html( strtoupper( $email ) ); ?>
                </a>
            </div>

            <div class="topbar__lang" aria-label="<?php esc_attr_e('Changer de langue', 'asicom'); ?>">
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:16px;height:16px;" aria-hidden="true">
                    <circle cx="12" cy="12" r="10"/>
                    <line x1="2" y1="12" x2="22" y2="12"/>
                    <path d="M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>
                </svg>
                <span>FR</span>
                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" style="width:12px;height:12px;" aria-hidden="true">
                    <polyline points="6 9 12 15 18 9"/>
                </svg>
            </div>

        </div>
    </div>
</div>

<!-- ============================================================
     HEADER — Navigation principale
     ============================================================ -->
<header class="site-header" id="site-header" role="banner">
    <div class="container">
        <div class="header__inner">

            <!-- Logo -->
            <a href="<?php echo esc_url( home_url('/') ); ?>" class="site-logo" aria-label="<?php bloginfo('name'); ?> — Accueil">
                <?php
                if ( has_custom_logo() ) :
                    the_custom_logo();
                else :
                ?>
                    <img
                        src="<?php echo esc_url( ASICOM_URI . '/assets/images/logo-asicom.png' ); ?>"
                        alt="<?php bloginfo('name'); ?>"
                        width="120"
                        height="52"
                        loading="eager"
                    >
                <?php endif; ?>
            </a>

            <!-- Navigation desktop -->
            <nav class="site-nav" id="site-nav" aria-label="<?php esc_attr_e('Navigation principale', 'asicom'); ?>">
                <?php
                wp_nav_menu([
                    'theme_location' => 'primary',
                    'menu_class'     => 'nav-menu',
                    'container'      => false,
                    'fallback_cb'    => function() {
                        echo '<ul class="nav-menu">';
                        echo '<li><a href="' . home_url('/') . '">Accueil</a></li>';
                        echo '<li><a href="' . home_url('/a-propos/') . '">À Propos</a></li>';
                        echo '<li><a href="' . home_url('/projets/') . '">Portefeuilles</a></li>';
                        echo '</ul>';
                    },
                ]);
                ?>

                <a href="<?php echo esc_url( home_url('/rendez-vous/') ); ?>" class="btn btn--primary">
                    Rendez-vous
                </a>
            </nav>

            <!-- Bouton hamburger (mobile) -->
            <button
                class="nav-toggle"
                id="nav-toggle"
                aria-expanded="false"
                aria-controls="mobile-menu"
                aria-label="<?php esc_attr_e('Ouvrir le menu', 'asicom'); ?>"
            >
                <span></span>
                <span></span>
                <span></span>
            </button>

        </div>
    </div>

    <!-- Navigation mobile -->
    <div class="mobile-menu" id="mobile-menu" aria-hidden="true">
        <div class="container">
            <?php
            wp_nav_menu([
                'theme_location' => 'primary',
                'menu_class'     => 'nav-menu',
                'container'      => false,
                'fallback_cb'    => function() {
                    echo '<ul class="nav-menu">';
                    echo '<li><a href="' . home_url('/') . '">Accueil</a></li>';
                    echo '<li><a href="' . home_url('/a-propos/') . '">À Propos</a></li>';
                    echo '<li><a href="' . home_url('/projets/') . '">Portefeuilles</a></li>';
                    echo '</ul>';
                },
            ]);
            ?>
            <a href="<?php echo esc_url( home_url('/rendez-vous/') ); ?>" class="btn btn--primary">
                Prendre un rendez-vous
            </a>
        </div>
    </div>

</header>
